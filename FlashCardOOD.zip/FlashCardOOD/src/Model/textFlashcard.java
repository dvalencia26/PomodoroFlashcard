package Model;

public class textFlashcard extends sessionTemplate{
    @Override
    void initialize() {

    }

    @Override
    void displayQuestion() {

    }

    @Override
    void getUserInput() {

    }

    @Override
    void getAnswer() {

    }

    @Override
    void giveFeedback() {

    }

    @Override
    void endSession() {

    }
}
