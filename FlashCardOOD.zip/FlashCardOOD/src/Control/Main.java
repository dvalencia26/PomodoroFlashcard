package Control;

import View.CreateFlashcardDisplay;
import View.DisplayHome;

public class Main {
    public static void main(String[] args){
        new DisplayHome();
    }
}
